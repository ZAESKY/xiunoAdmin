
<?php exit;
include _include(APP_PATH.'plugin/zaesky_theme_light/model/light.func.admin.php');
?>