<?php
 $action = param(1);
  $light_config = setting_get('admin_light_setting');
  $main_switch = 'col-lg-7';
  $index_header_switch = 'hidden-lg';
  $icon_switch = 'hidden-sm hidden-md';
  $thread_nav_switch = 'd-none';
  $thread_left_l = 'd-lg-block';
  $thread_left_m = 'col-lg-8';
  $footer_icon_switch = 'col-lg-9';
  if (isset($light_config['side_nav_switch']) && $light_config['side_nav_switch'] == 0) { 
    $main_switch = 'col-lg-9';
    $index_header_switch = '';
    $icon_switch='d-none';
  }
  if (isset($light_config['thread_top_nav']) && $light_config['thread_top_nav'] == 1) { 
    $thread_nav_switch = '';
  }
  if (isset($light_config['thread_left_switch']) && $light_config['thread_left_switch'] == 0) {
    $thread_left_l = '';
    $thread_left_m = 'col-lg-9';
     }
     if (isset($light_config['footer_icon_show']) && $light_config['footer_icon_show'] == 1) {
        $footer_icon_switch = 'col-lg-7';
     }

     //数字转换
     function convert($num) {
      if ($num >= 100000){
          $num = round($num / 10000) .'w';
      } 
      else if ($num >= 10000) {
          $num = round($num / 10000, 1) .'w';
      } 
      else if($num >= 1000) {
          $num = round($num / 1000, 1) . 'k';
      }
      return $num;
  } 

  //小伙伴们
  function discovery_get_site_new_user($num){
    //先获取用户列表
    $userlist = cache_get('get_site_new_user');
    if(empty($userlist)){
        $userlist = db_find('user', array(), array('login_date'=>-1), 1, $num, 'uid');
        foreach ($userlist as &$user) {
            $username = $user['username'];
            $user['dname'] = $username;
        }
        cache_set('get_site_new_user',$userlist,3600);//有效期1小时
    }
    return $userlist;
  }
  
  //热门板块
  function discovery_get_hot_forum(){
  $hotforumList = cache_get('discovery_get_hot_forum');
  if(empty($hotforumList)){
    $hotforumList = db_find('forum',array(),array('threads'=>-1),1,3);
    cache_set('discovery_get_hot_forum',$hotforumList,86400);//有效期1天
  }
  
  return $hotforumList;
  }
  //财富榜
  function discovery_get_gold_List(){
  $goldRankList = cache_get('discovery_get_gold_List');
  if(empty($goldRankList)){
    $goldRankList = db_find('user',array(),array('golds'=>-1),1,5);
    cache_set('discovery_get_gold_List',$goldRankList,86400);//有效期1天
  }
 
  return $goldRankList;
}
  //贡献榜
  function discovery_get_thread_List(){
  $threadRankList = cache_get('discovery_get_thread_List');
  if(empty($threadRankList)){
    $threadRankList = db_find('user',array(),array('threads'=>-1),1,5);
    cache_set('discovery_get_thread_List',$threadRankList,86400);//有效期1天
  }
 
  return $threadRankList;
  }
  //活跃榜
  function discovery_get_login_List(){
  $loginRankList = cache_get('discovery_get_login_List');
  if(empty($loginRankList)){
    $loginRankList = db_find('user',array(),array('logins'=>-1),1,5);
    cache_set('discovery_get_login_List',$loginRankList,86400);//有效期1天
  }
  return $loginRankList;
}

  //获取回复最多的文章，默认10篇，总排行
  function discovery_get_site_top_list(){
    $result = cache_get('discovery_get_site_top_list');
    if(empty($result)){
      $result = db_find('thread', array('views' =>array('>'=>100),'posts'=>array('>'=>20)), array('views'=>2),1,20);//按views倒序
      cache_set('discovery_get_site_top_list',$result,86400);//有效期1天
    }
    return $result;
  } 

  //获取最新的帖子
  function get_new_threadlist(){
    $newList = db_find('thread',array(),array('create_date'=>-1),1,8);
    return $newList;
  }

    //获取最新回复的帖子
    function get_new_reply_threadlist(){
      $newReplyList = db_find('thread',array(),array('last_date'=>-1),1,8);
      return $newReplyList;
    }
     
  //最新评论
  function discovery_get_comment_list() {
    $cachename = "discovery_get_comment_list";
    $threadlist = cache_get($cachename);
    if($threadlist === NULL) {
      $threadlist = post_find( array( "isfirst" => 0, "quotepid" => 0 ), array( "create_date" => "-1" ), 1, 8 );
      cache_set($cachename, $threadlist, 600);
    }
    return $threadlist;
  }
  

  $arronline=assoc_unique(online_list_cache(),'uid');//获取在线用户信息并且根据uid值去重复

$rew=$conf['url_rewrite_on']==0 ? '?':'';//伪静态

function assoc_unique($arr, $key) {  //根据指定的key值为数组去重
        $tmp_arr = array();  
        foreach($arr as $k => $v) {  
            if(in_array($v[$key], $tmp_arr)) {  
                unset($arr[$k]);  
            } else {  
                $tmp_arr[] = $v[$key];  
            }  
        }  
        sort($arr);  
        return $arr;  
} 
function getlistn(){//返回修罗主程序所处相对目录 
return substr($_SERVER['PHP_SELF'],0,strlen($_SERVER['PHP_SELF'])-10);   
}

function ShuLiang($url)
{
    $sl=0;
    $arr = glob($url);
    foreach ($arr as $v)
    {
        if(is_file($v))
        {
            $sl++;
        }
        else
        {
            $sl+=ShuLiang($v."/*");
        }
    }
    return $sl;
}


function getUnread_notices($uid){
  $result = db_sql_find("SELECT unread_notices FROM bbs_user WHERE uid = $uid;");
  return $result[0]['unread_notices'];
}

function getPublishCounts($uid, $days = 7) {
  // 获取当前日期和过去指定天数的日期
  $currentDate = date('Y-m-d');
  $dates = [];
  for ($i = 0; $i < $days; $i++) {
      $dates[] = date('Y-m-d', strtotime("-$i days", strtotime($currentDate)));
  }

  // 反转数组以确保日期按升序排列
  $dates = array_reverse($dates);

  // 构建SQL查询
  $sql = "
  SELECT 
      DATE(FROM_UNIXTIME(create_date)) AS publish_date, 
      COUNT(*) AS publish_count
  FROM 
      bbs_post
  WHERE 
      uid = :uid
      AND create_date >= UNIX_TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL :days DAY)) 
      AND isfirst = 0
  GROUP BY 
      DATE(FROM_UNIXTIME(create_date))
  ORDER BY 
      publish_date ASC;
  ";

  $results = db_sql_find($sql);

  // 将查询结果转换为按日期为键的数组
  $publishCounts = [];
  foreach ($results as $row) {
      $publishCounts[$row['publish_date']] = (int)$row['publish_count'];
  }

  // 创建最终结果数组，确保每天都有数据
  $finalResult = array_fill(0, $days, ['publish_date' => '', 'publish_count' => 0]);
  foreach ($dates as $index => $date) {
      $finalResult[$index] = [
          'publish_date' => $date,
          'publish_count' => $publishCounts[$date] ?? 0
      ];
  }

  return $finalResult;
}

function getUserRegistrationDays($registrationTimestamp) {
    if ($registrationTimestamp) {
        $currentDate = time();
        $days = ($currentDate - $registrationTimestamp) / (60 * 60 * 24); // 计算注册天数
        return ceil($days); // 如果不足一天，按一天算
    }
    return 0; // 如果用户不存在，返回0
}
  
?>