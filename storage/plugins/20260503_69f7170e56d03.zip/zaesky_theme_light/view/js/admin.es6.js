/**
 * API请求封装
 */
const apiRequest = {
    // 通用GET请求
    get: (url) => {
        return new Promise((resolve, reject) => {
            $.xget(url, (code, message) => {
                if (code === 0) {
                    try {
                        const data = JSON.parse(message);
                        resolve(data);
                    } catch (e) {
                        reject(new Error('JSON解析失败'));
                    }
                } else {
                    reject(new Error(message));
                }
            });
        });
    },

    // 通用POST请求
    post: (url, data) => {
        return new Promise((resolve, reject) => {
            $.xpost(url, data, (code, message) => {
                if (code === 0) {
                    resolve(message);
                } else {
                    reject(new Error(message));
                }
            });
        });
    }
};

// 问候语配置
const greetings = [
    { start: 0, end: 5, message: "深夜安好", description: "夜深了，请注意休息，保重身体", icon: "fa-moon" },
    { start: 5, end: 9, message: "清晨愉快", description: "一日之计在于晨，祝您拥有美好的一天", icon: "fa-sun" },
    { start: 9, end: 12, message: "上午好", description: "上午时光宝贵，祝您工作顺利", icon: "fa-coffee" },
    { start: 12, end: 14, message: "午安", description: "午餐时间到了，记得补充能量哦", icon: "fa-utensils" },
    { start: 14, end: 18, message: "下午好", description: "下午继续加油，保持高效工作", icon: "fa-laptop" },
    { start: 18, end: 22, message: "晚上好", description: "忙碌了一天，是时候放松一下了", icon: "fa-star" },
    { start: 22, end: 24, message: "晚安", description: "愿您有个宁静舒适的夜晚，好梦", icon: "fa-bed" }
];

// 获取当前问候语
const getCurrentGreeting = () => {
    const now = new Date();
    const hours = now.getHours();

    return greetings.find(greeting =>
        hours >= greeting.start && hours < greeting.end
    ) || {
        message: "欢迎到来！",
        description: "我们根据当前时间为您显示最合适的问候",
        icon: "fa-smile"
    };
};


const initGreeting = () => {
    const currentGreeting = getCurrentGreeting();

    // 设置问候语内容
    document.getElementById('greeting-message').textContent = currentGreeting.message;
    document.getElementById('greeting-description').textContent = currentGreeting.description;
    document.getElementById('greeting-icon').className = `fas ${currentGreeting.icon}`;

    // 更新时间显示
    const updateTime = () => {
        const now = new Date();
        const timeString = now.toLocaleTimeString('zh-CN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        document.getElementById('current-time').textContent = `当前时间: ${timeString}`;
    };

    // 初始更新时间
    updateTime();

    // 每秒更新一次时间
    setInterval(updateTime, 1000);
};

$('#nav li.home').addClass('active');

// 检查授权状态
const checkAuth = async () => {
    try {
        const authInfo = await apiRequest.get(xn.url("index-checkAuth"));
        $("#authStatus").html(authInfo.msg);
    } catch (error) {
        console.error('检查授权失败:', error);
    }
};

// 检查更新
const checkUpdate = async (pop = 0) => {
    if (pop) {
        $('body').mLoading({
            text: "检测更新中，请稍等...",
        });
    }

    // 禁用按钮并显示加载图标
    const updateButton = $(".btn.btn-alt-success");
    updateButton.prop("disabled", true);
    updateButton.html('<i class="si si-reload fa-spin opacity-50 me-1"></i> 检测中...');

    try {
        const updateInfo = await apiRequest.get(xn.url("index-checkUpdate"));
        console.log(updateInfo);

        if (updateInfo.code === 0) {
            updateStatusDisplay(updateInfo, pop);
        } else {
            $.alert(updateInfo.msg);
        }
    } catch (error) {
        $.alert(error.message);
    } finally {
        // 恢复按钮状态
        updateButton.prop("disabled", false);
        updateButton.html('<i class="si si-reload opacity-50 me-1"></i> 检测更新');
        $('body').mLoading("hide");
    }
};

const updateStatusDisplay = (updateInfo, pop = 0) => {
    const $status = $("#updateStatus");
    const $statusTitle = $("#updateStatus_title");
    const $statusIcon = $("#updateStatus_icon");
    const displayMessage = updateInfo.msg;
    $status.html(displayMessage);

    if (!updateInfo.data?.data?.data) {
        if (pop === 1) {
            $.alert(displayMessage);
        }
        return;
    }

    // 更新状态显示
    $statusTitle.html("有新版本");
    $statusIcon.removeClass("si-check").addClass("si-cloud-download");

    const updateData = updateInfo.data.data.data;
    const updateLogInfo = updateData.update_log;

    // 构建更新日志信息
    let logContent = `
        <div class="p-3">
            <h5 class="mb-3">版本信息</h5>
            <p class="mb-2"><span class="text-muted">最新版本：</span>${updateData.edition}</p>
            <p class="mb-2"><span class="text-muted">更新说明：</span></p>
            <div class="alert alert-info">
    `;

    // 遍历更新日志对象
    for (const date in updateLogInfo) {
        logContent += `<p class="mb-2"><strong>${date}</strong></p><ul class="mb-3 pl-4">`;
        updateLogInfo[date].forEach(item => {
            logContent += `<li>${item}</li>`;
        });
        logContent += '</ul>';
    }
    logContent += '</div></div>';

    if (pop === 1) {
        $.confirm(logContent, update);
    } else {
        $status.html(updateInfo.msg);
    }
};

// 执行更新
const update = async () => {
    $('body').mLoading({
        text: "下载更新中，请稍等...",
    });

    try {
        const result = await apiRequest.get(xn.url("index-update"));
        $.alert(result);

        setTimeout(async () => {
            try {
                await apiRequest.post(xn.url("other-cache"), "clear_tmp=1&clear_cache=1");
                window.location.reload();
            } catch (error) {
                console.error('清理缓存失败:', error);
                window.location.reload();
            }
        }, 2000);
    } catch (error) {
        $.alert(error.message);
    } finally {
        $('body').mLoading("hide");
    }
};

// 存储事件数据
let events = JSON.parse(localStorage.getItem('calendarEvents')) || {};
let selectedDate = null;

// 获取当前日期并计算显示范围（前3天到后3天）
const today = new Date();
today.setHours(0, 0, 0, 0); // 重置时间，确保日期比较准确
const displayDates = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(today);
    date.setDate(today.getDate() + (i - 3));
    return date;
});

// 初始化日历
const initCalendar = () => {
    renderCalendarDays();
    updateMonthYearDisplay();
    setupEventListeners();
};

// 渲染日历日期
const renderCalendarDays = () => {
    const calendarDays = document.getElementById('calendar-days');
    calendarDays.innerHTML = '';

    displayDates.forEach(date => {
        // 创建列容器
        const col = document.createElement('div');
        col.className = 'd-flex justify-content-center';

        // 创建日期元素
        const dayElement = document.createElement('div');
        const isToday = date.toDateString() === today.toDateString();
        const isPast = date < today;
        const dateStr = formatDate(date);

        // 设置日期样式
        dayElement.className = `calendar-day d-flex flex-column justify-content-center align-items-center position-relative ${isToday ? 'calendar-day-active' : ''} ${isPast ? 'calendar-day-past' : ''}`;

        // 如果是今天，设置为选中状态
        if (isToday) {
            selectedDate = dateStr;
            updateEventsDisplay();
            updateAddEventButtonState(date);
        }

        // 日期数字
        const dayNumber = document.createElement('span');
        dayNumber.className = isToday ? 'font-weight-bold' : '';
        dayNumber.textContent = date.getDate();

        // 星期几（简短显示）
        const dayName = document.createElement('span');
        dayName.className = 'small mt-1';
        dayName.textContent = ['日', '一', '二', '三', '四', '五', '六'][date.getDay()];

        dayElement.appendChild(dayNumber);
        dayElement.appendChild(dayName);

        // 添加点击事件
        dayElement.addEventListener('click', () => {
            // 移除之前选中日期的样式
            document.querySelectorAll('.calendar-day-active').forEach(el => {
                el.classList.remove('calendar-day-active');
            });

            // 添加当前选中日期的样式
            dayElement.classList.add('calendar-day-active');

            // 更新选中日期并显示事件
            selectedDate = dateStr;
            updateEventsDisplay();
            updateAddEventButtonState(date);
        });

        // 如果有事件，添加指示点
        if (events[dateStr] && events[dateStr].length > 0) {
            const eventIndicator = document.createElement('span');
            eventIndicator.className = `event-indicator ${isToday ? 'bg-white' : isPast ? 'bg-secondary' : 'bg-primary'}`;
            dayElement.appendChild(eventIndicator);
        }

        col.appendChild(dayElement);
        calendarDays.appendChild(col);
    });
};

// 更新月份和年份显示
const updateMonthYearDisplay = () => {
    const monthYearElement = document.getElementById('current-month-year');
    const monthNames = ['一月', '二月', '三月', '四月', '五月', '六月',
        '七月', '八月', '九月', '十月', '十一月', '十二月'];

    // 检查所有显示的日期是否在同一个月
    const firstMonth = displayDates[0].getMonth();
    const lastMonth = displayDates[displayDates.length - 1].getMonth();
    const year = displayDates[0].getFullYear();

    const displayText = firstMonth === lastMonth
        ? `${monthNames[firstMonth]} ${year}`
        : `${monthNames[firstMonth]} - ${monthNames[lastMonth]} ${year}`;

    monthYearElement.textContent = displayText;
};

// 更新事件显示
const updateEventsDisplay = () => {
    const eventsContainer = document.getElementById('events-container');

    // 清空容器
    eventsContainer.innerHTML = '';

    // 如果没有事件
    if (!events[selectedDate] || events[selectedDate].length === 0) {
        eventsContainer.innerHTML = `
            <div class="text-center text-muted py-5">
                <i class="far fa-calendar text-3xl mb-2 opacity-30"></i>
                <p class="mb-0">该日期暂无事项</p>
            </div>
        `;
        return;
    }

    // 按时间排序事件
    const sortedEvents = [...events[selectedDate]].sort((a, b) => a.time.localeCompare(b.time));

    // 添加事件到容器
    sortedEvents.forEach((event, index) => {
        const eventElement = document.createElement('div');
        eventElement.className = 'event-item bg-white p-3 rounded border mb-2 slide-in';
        eventElement.style.animationDelay = `${index * 50}ms`;

        eventElement.innerHTML = `
            <div class="d-flex justify-content-between align-items-start">
                <div>
                    <h4 class="font-medium text-dark mb-1">${event.title}</h4>
                    ${event.time ? `<p class="small text-primary mb-0">${event.time}</p>` : ''}
                    ${event.description ? `<p class="small text-muted mt-1 mb-0">${event.description}</p>` : ''}
                </div>
                <div class="delete-event text-muted" data-index="${index}">
                    <i class="far fa-trash-can"></i>
                </div>
            </div>
        `;

        eventsContainer.appendChild(eventElement);

        // 添加删除事件监听
        eventElement.querySelector('.delete-event').addEventListener('click', (e) => {
            const index = parseInt(e.currentTarget.dataset.index);
            deleteEvent(index);
        });
    });
};

// 根据日期更新添加事件按钮状态
const updateAddEventButtonState = (date) => {
    const addButton = document.getElementById('add-event-btn');
    const isPast = date < today;

    if (isPast) {
        // 过去的日期 - 禁用按钮
        addButton.disabled = true;
        addButton.classList.add('disabled', 'opacity-50');
        addButton.classList.remove('btn-primary');
        addButton.classList.add('btn-secondary');
    } else {
        // 今天或未来的日期 - 启用按钮
        addButton.disabled = false;
        addButton.classList.remove('disabled', 'opacity-50', 'btn-secondary');
        addButton.classList.add('btn-primary');
    }
};

// 打开添加事件弹窗
const openEventModal = () => {
    document.getElementById('modal-date').value = selectedDate;

    // 清空表单
    document.getElementById('event-title').value = '';
    document.getElementById('event-time').value = '';
    document.getElementById('event-description').value = '';

    // 使用Bootstrap模态框方法显示
    $('#event-modal').modal('show');

    // 聚焦到标题输入框
    setTimeout(() => {
        document.getElementById('event-title').focus();
    }, 300);
};

// 保存事件
const saveEvent = () => {
    const date = document.getElementById('modal-date').value;
    const title = document.getElementById('event-title').value.trim();
    const time = document.getElementById('event-time').value;
    const description = document.getElementById('event-description').value.trim();

    // 验证标题
    if (!title) {
        alert('请输入事项标题');
        return;
    }

    // 创建事件对象
    const event = { title, time, description };

    // 保存到事件数据中
    if (!events[date]) {
        events[date] = [];
    }
    events[date].push(event);

    // 保存到本地存储
    localStorage.setItem('calendarEvents', JSON.stringify(events));

    // 关闭弹窗
    $('#event-modal').modal('hide');

    // 更新显示
    renderCalendarDays();
    updateEventsDisplay();
};

// 删除事件
const deleteEvent = (index) => {
    $.confirm('确定删除该事项吗？', () => {
        events[selectedDate].splice(index, 1);

        // 如果该日期没有事件了，删除该日期的键
        if (events[selectedDate].length === 0) {
            delete events[selectedDate];
        }

        // 保存到本地存储
        localStorage.setItem('calendarEvents', JSON.stringify(events));

        // 更新显示
        renderCalendarDays();
        updateEventsDisplay();
    });
};



// 设置事件监听器
const setupEventListeners = () => {
    // 添加事项按钮
    document.getElementById('add-event-btn').addEventListener('click', openEventModal);

    // 保存事件按钮
    document.getElementById('save-event').addEventListener('click', saveEvent);

    // 按ESC键关闭弹窗
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && $('#event-modal').hasClass('show')) {
            $('#event-modal').modal('hide');
        }
    });

    // 按Enter键保存事件（当弹窗打开时）
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && $('#event-modal').hasClass('show')) {
            saveEvent();
        }
    });
};

// 格式化日期为YYYY-MM-DD
const formatDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

// 封装图表初始化逻辑
const initUserChart = (registerData) => {
    const sparklineData = registerData.counts;

    const spark3 = {
        chart: {
            id: 'sparkline3',
            group: 'sparklines',
            type: 'area',
            height: 67,
            sparkline: { enabled: true },
        },
        stroke: { curve: 'smooth' },
        fill: { opacity: 1 },
        series: [{
            name: '新注册用户',
            data: sparklineData
        }],
        labels: registerData.dates,
        xaxis: { type: 'text' },
        yaxis: { min: 0 },
        colors: ['#008FFB'],
    };

    // 渲染图表
    new ApexCharts(document.querySelector("#spark3"), spark3).render();
};

const initGroupChart = (grouprData) => {
    const options = {
        series: grouprData.series,
        chart: {
            type: 'donut',
        },
        labels: grouprData.labels,
        // 新增全局图例配置
        legend: {
            position: 'bottom', // 可选值：'top'、'bottom'
            horizontalAlign: 'center' // 水平对齐方式（可选）
        },
    };

    const chart = new ApexCharts(document.querySelector("#js-chartjs-pie"), options);
    chart.render();
};

const renderLastPostsAndThread = (threadData) => {
    // 转换日期格式：将完整日期转为只显示日（10月15日 -> 15），同时处理跨年日期
    const formattedDates = threadData['days'].map(dateStr => {
        const [year, month, day] = dateStr.split('-');
        // 添加跨年标识（如果包含去年）
        if (new Date().getFullYear() - year > 0) {
            return `${month}/${day}`;
        }
        return `${parseInt(day, 10)}日`;
    });

    var options = {
        series: [{
            name: '发帖数',
            data: threadData['new_threads']
        }, {
            name: '回帖数',
            data: threadData['new_replies']
        }],
        chart: {
            type: 'bar',
            height: 293,
            stacked: true,
            // 移除顶部工具栏
            toolbar: { show: false },
            // 移除菜单按钮
            zoom: { enabled: false },
            selection: { enabled: false }
        },
        plotOptions: {
            bar: {
                horizontal: false,
                borderRadius: 4,  // 统一的圆角
                columnWidth: '65%',  // 更紧凑的宽度
                dataLabels: {
                    position: 'center'  // 数值显示在顶部
                }
            }
        },
        dataLabels: {
            enabled: true,
            formatter: function(val) {
                return val > 0 ? val : '';  // 0值不显示
            },
            style: {
                fontSize: '10px',
                colors: ['#444']
            }
        },
        xaxis: {
            type: 'category',
            categories: formattedDates,  // 使用转换后的日期
            axisBorder: { show: false },  // 移除轴线
            axisTicks: { show: false },   // 移除刻度线
            labels: {
                style: {
                    fontSize: '11px',
                    fontWeight: 600
                }
            }
        },
        yaxis: {
            show: false,  // 隐藏Y轴
        },
        legend: {
            position: 'bottom',
            fontSize: '12px',
            markers: {
                width: 10,
                height: 10,
                radius: 3
            },
            itemMargin: {
                horizontal: 12
            }
        },
        grid: {
            show: false,  // 移除网格线
            padding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            }
        },
        tooltip: {
            x: {
                // 提示框显示完整日期
                formatter: function(_, opts) {
                    return threadData['days'][opts.dataPointIndex];
                }
            },
            y: {
                title: {
                    formatter: (seriesName) => seriesName
                }
            }
        },
    };

    var chart = new ApexCharts(document.querySelector("#threadDataChart"), options);
    chart.render();
}

/* JS部分 - 动态渲染表格 */
const renderGroupTable = (groupTableData) => {
    const tbody = document.getElementById('group-table-body');
    let html = '';

    groupTableData.forEach(group => {
        let userAvatars = '';

        // 生成用户头像HTML
        group.users.forEach(user => {
            userAvatars += `
                <a href="${user.profile_url}" 
                   data-toggle="tooltip" 
                   data-placement="top" 
                   title="${user.username}">
                    <img src="${user.avatar}" class="avatar-2">
                </a>
            `;
        });

        // 生成行HTML
        html += `
        <tr>
            <td data-label="ID">${group.gid}</td>
            <td data-label="用户组名称"><a href="${group.list_url}">${group.name}</a></td>
            <td data-label="成员"><div>${userAvatars}</div></td>
            <td data-label="成员数">
                <span class="badge ${group.badge_color}">${group.count}</span>
            </td>
        </tr>
        `;
    });

    tbody.innerHTML = html;

    // 初始化tooltip（如使用Bootstrap）
    if ($) {
        $('[data-toggle="tooltip"]').tooltip();
    }
};