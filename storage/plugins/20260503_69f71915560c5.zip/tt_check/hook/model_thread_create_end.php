<?php exit;
global $group;
$check_result = check_or_not($group,$fid,'thread');
if($check_result){
  check_set_thread_check($tid,'0');
  $thread_msg = thread_read($tid);
	$thread_msg['subject'] = notice_substr($thread_msg['subject'], 20);
	$notice_thread_msg = '<a target="_blank" href="'.url('thread-'.$thread_msg['tid']).'">《'.$thread_msg['subject'].'》</a>';
    $notice_msg = '主题等待审核：'.  $notice_thread_msg;
    notice_send('2', 1, $notice_msg, 3);
};
?>