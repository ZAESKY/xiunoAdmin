<?php
// ThemeLightInstaller.php

require_once 'install_config.php';

class ThemeLightInstaller {
    private static $db;
    private static $tablepre;
    
    public function __construct($db) {
        self::$db = $db;
        self::$tablepre = $db->tablepre;
    }

    public static function install() {
        // 检查 Authorization.php 是否存在
        if (!file_exists(__DIR__ . '/Authorization.php')) {
            message(-1, '<div class="text-center"><h2 class="text-danger mb-4"><i class="icon-times-circle"></i> 安装失败</h2><div class="alert alert-danger mb-4"><h5><i class="icon-exclamation-circle"></i> 错误信息</h5><p>文件缺失，无法继续安装。请重新下载。</p></div></div>');
            return;
        }

        // 创建数据表
        ThemeLightHelper::createTables(self::$db);

        // 设置默认配置
        setting_set('admin_light_setting', ThemeLightHelper::getDefaultConfig());

        // 显示安装成功信息
        message(-1, '<div class="text-center"><h2 class="text-success mb-4"><i class="icon-check-circle"></i> 安装成功</h2><div class="alert alert-info mb-4"><h5><i class="icon-info-circle"></i> 使用须知</h5><ul class="list-unstyled text-left mb-0"><li><i class="icon-check mr-2"></i>建议PHP版本≥7.3，并配置伪静态</li><li><i class="icon-check mr-2"></i>升级时请先删除原插件目录再安装</li><li><i class="icon-check mr-2"></i>主题已专门适配，请勿随意分享外传</li></ul></div><div class="alert alert-warning"><i class="icon-heart text-danger"></i> 感谢使用！请支持正版，抵制盗版！</div><div class="mt-4"><a class="btn btn-primary mr-3" href="./'.url("plugin-setting-zaesky_theme_light").'"><i class="icon-cog"></i> 主题设置</a><a class="btn btn-info" href="https://www.noteweb.top/" target="_blank"><i class="icon-globe"></i> 访问官网</a></div></div>');
    }
}