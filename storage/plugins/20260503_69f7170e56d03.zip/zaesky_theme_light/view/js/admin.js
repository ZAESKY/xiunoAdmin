"use strict";

function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i["return"]) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
/**
 * API请求封装
 */
var apiRequest = {
  // 通用GET请求
  get: function get(url) {
    return new Promise(function (resolve, reject) {
      $.xget(url, function (code, message) {
        if (code === 0) {
          try {
            var data = JSON.parse(message);
            resolve(data);
          } catch (e) {
            reject(new Error('JSON解析失败'));
          }
        } else {
          reject(new Error(message));
        }
      });
    });
  },
  // 通用POST请求
  post: function post(url, data) {
    return new Promise(function (resolve, reject) {
      $.xpost(url, data, function (code, message) {
        if (code === 0) {
          resolve(message);
        } else {
          reject(new Error(message));
        }
      });
    });
  }
};

// 问候语配置
var greetings = [{
  start: 0,
  end: 5,
  message: "深夜安好",
  description: "夜深了，请注意休息，保重身体",
  icon: "fa-moon"
}, {
  start: 5,
  end: 9,
  message: "清晨愉快",
  description: "一日之计在于晨，祝您拥有美好的一天",
  icon: "fa-sun"
}, {
  start: 9,
  end: 12,
  message: "上午好",
  description: "上午时光宝贵，祝您工作顺利",
  icon: "fa-coffee"
}, {
  start: 12,
  end: 14,
  message: "午安",
  description: "午餐时间到了，记得补充能量哦",
  icon: "fa-utensils"
}, {
  start: 14,
  end: 18,
  message: "下午好",
  description: "下午继续加油，保持高效工作",
  icon: "fa-laptop"
}, {
  start: 18,
  end: 22,
  message: "晚上好",
  description: "忙碌了一天，是时候放松一下了",
  icon: "fa-star"
}, {
  start: 22,
  end: 24,
  message: "晚安",
  description: "愿您有个宁静舒适的夜晚，好梦",
  icon: "fa-bed"
}];

// 获取当前问候语
var getCurrentGreeting = function getCurrentGreeting() {
  var now = new Date();
  var hours = now.getHours();
  return greetings.find(function (greeting) {
    return hours >= greeting.start && hours < greeting.end;
  }) || {
    message: "欢迎到来！",
    description: "我们根据当前时间为您显示最合适的问候",
    icon: "fa-smile"
  };
};
var initGreeting = function initGreeting() {
  var currentGreeting = getCurrentGreeting();

  // 设置问候语内容
  document.getElementById('greeting-message').textContent = currentGreeting.message;
  document.getElementById('greeting-description').textContent = currentGreeting.description;
  document.getElementById('greeting-icon').className = "fas ".concat(currentGreeting.icon);

  // 更新时间显示
  var updateTime = function updateTime() {
    var now = new Date();
    var timeString = now.toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    document.getElementById('current-time').textContent = "\u5F53\u524D\u65F6\u95F4: ".concat(timeString);
  };

  // 初始更新时间
  updateTime();

  // 每秒更新一次时间
  setInterval(updateTime, 1000);
};
$('#nav li.home').addClass('active');

// 检查授权状态
var checkAuth = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee() {
    var authInfo, _t;
    return _regenerator().w(function (_context) {
      while (1) switch (_context.p = _context.n) {
        case 0:
          _context.p = 0;
          _context.n = 1;
          return apiRequest.get(xn.url("index-checkAuth"));
        case 1:
          authInfo = _context.v;
          $("#authStatus").html(authInfo.msg);
          _context.n = 3;
          break;
        case 2:
          _context.p = 2;
          _t = _context.v;
          console.error('检查授权失败:', _t);
        case 3:
          return _context.a(2);
      }
    }, _callee, null, [[0, 2]]);
  }));
  return function checkAuth() {
    return _ref.apply(this, arguments);
  };
}();

// 检查更新
var checkUpdate = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2() {
    var pop,
      updateButton,
      updateInfo,
      _args2 = arguments,
      _t2;
    return _regenerator().w(function (_context2) {
      while (1) switch (_context2.p = _context2.n) {
        case 0:
          pop = _args2.length > 0 && _args2[0] !== undefined ? _args2[0] : 0;
          if (pop) {
            $('body').mLoading({
              text: "检测更新中，请稍等..."
            });
          }

          // 禁用按钮并显示加载图标
          updateButton = $(".btn.btn-alt-success");
          updateButton.prop("disabled", true);
          updateButton.html('<i class="si si-reload fa-spin opacity-50 me-1"></i> 检测中...');
          _context2.p = 1;
          _context2.n = 2;
          return apiRequest.get(xn.url("index-checkUpdate"));
        case 2:
          updateInfo = _context2.v;
          console.log(updateInfo);
          if (updateInfo.code === 0) {
            updateStatusDisplay(updateInfo, pop);
          } else {
            $.alert(updateInfo.msg);
          }
          _context2.n = 4;
          break;
        case 3:
          _context2.p = 3;
          _t2 = _context2.v;
          $.alert(_t2.message);
        case 4:
          _context2.p = 4;
          // 恢复按钮状态
          updateButton.prop("disabled", false);
          updateButton.html('<i class="si si-reload opacity-50 me-1"></i> 检测更新');
          $('body').mLoading("hide");
          return _context2.f(4);
        case 5:
          return _context2.a(2);
      }
    }, _callee2, null, [[1, 3, 4, 5]]);
  }));
  return function checkUpdate() {
    return _ref2.apply(this, arguments);
  };
}();
var updateStatusDisplay = function updateStatusDisplay(updateInfo) {
  var _updateInfo$data;
  var pop = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var $status = $("#updateStatus");
  var $statusTitle = $("#updateStatus_title");
  var $statusIcon = $("#updateStatus_icon");
  var displayMessage = updateInfo.msg;
  $status.html(displayMessage);
  if (!((_updateInfo$data = updateInfo.data) !== null && _updateInfo$data !== void 0 && (_updateInfo$data = _updateInfo$data.data) !== null && _updateInfo$data !== void 0 && _updateInfo$data.data)) {
    if (pop === 1) {
      $.alert(displayMessage);
    }
    return;
  }

  // 更新状态显示
  $statusTitle.html("有新版本");
  $statusIcon.removeClass("si-check").addClass("si-cloud-download");
  var updateData = updateInfo.data.data.data;
  var updateLogInfo = updateData.update_log;

  // 构建更新日志信息
  var logContent = "\n        <div class=\"p-3\">\n            <h5 class=\"mb-3\">\u7248\u672C\u4FE1\u606F</h5>\n            <p class=\"mb-2\"><span class=\"text-muted\">\u6700\u65B0\u7248\u672C\uFF1A</span>".concat(updateData.edition, "</p>\n            <p class=\"mb-2\"><span class=\"text-muted\">\u66F4\u65B0\u8BF4\u660E\uFF1A</span></p>\n            <div class=\"alert alert-info\">\n    ");

  // 遍历更新日志对象
  for (var date in updateLogInfo) {
    logContent += "<p class=\"mb-2\"><strong>".concat(date, "</strong></p><ul class=\"mb-3 pl-4\">");
    updateLogInfo[date].forEach(function (item) {
      logContent += "<li>".concat(item, "</li>");
    });
    logContent += '</ul>';
  }
  logContent += '</div></div>';
  if (pop === 1) {
    $.confirm(logContent, update);
  } else {
    $status.html(updateInfo.msg);
  }
};

// 执行更新
var update = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee4() {
    var result, _t4;
    return _regenerator().w(function (_context4) {
      while (1) switch (_context4.p = _context4.n) {
        case 0:
          $('body').mLoading({
            text: "下载更新中，请稍等..."
          });
          _context4.p = 1;
          _context4.n = 2;
          return apiRequest.get(xn.url("index-update"));
        case 2:
          result = _context4.v;
          $.alert(result);
          setTimeout(/*#__PURE__*/_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee3() {
            var _t3;
            return _regenerator().w(function (_context3) {
              while (1) switch (_context3.p = _context3.n) {
                case 0:
                  _context3.p = 0;
                  _context3.n = 1;
                  return apiRequest.post(xn.url("other-cache"), "clear_tmp=1&clear_cache=1");
                case 1:
                  window.location.reload();
                  _context3.n = 3;
                  break;
                case 2:
                  _context3.p = 2;
                  _t3 = _context3.v;
                  console.error('清理缓存失败:', _t3);
                  window.location.reload();
                case 3:
                  return _context3.a(2);
              }
            }, _callee3, null, [[0, 2]]);
          })), 2000);
          _context4.n = 4;
          break;
        case 3:
          _context4.p = 3;
          _t4 = _context4.v;
          $.alert(_t4.message);
        case 4:
          _context4.p = 4;
          $('body').mLoading("hide");
          return _context4.f(4);
        case 5:
          return _context4.a(2);
      }
    }, _callee4, null, [[1, 3, 4, 5]]);
  }));
  return function update() {
    return _ref3.apply(this, arguments);
  };
}();

// 存储事件数据
var events = JSON.parse(localStorage.getItem('calendarEvents')) || {};
var selectedDate = null;

// 获取当前日期并计算显示范围（前3天到后3天）
var today = new Date();
today.setHours(0, 0, 0, 0); // 重置时间，确保日期比较准确
var displayDates = Array.from({
  length: 7
}, function (_, i) {
  var date = new Date(today);
  date.setDate(today.getDate() + (i - 3));
  return date;
});

// 初始化日历
var initCalendar = function initCalendar() {
  renderCalendarDays();
  updateMonthYearDisplay();
  setupEventListeners();
};

// 渲染日历日期
var renderCalendarDays = function renderCalendarDays() {
  var calendarDays = document.getElementById('calendar-days');
  calendarDays.innerHTML = '';
  displayDates.forEach(function (date) {
    // 创建列容器
    var col = document.createElement('div');
    col.className = 'd-flex justify-content-center';

    // 创建日期元素
    var dayElement = document.createElement('div');
    var isToday = date.toDateString() === today.toDateString();
    var isPast = date < today;
    var dateStr = formatDate(date);

    // 设置日期样式
    dayElement.className = "calendar-day d-flex flex-column justify-content-center align-items-center position-relative ".concat(isToday ? 'calendar-day-active' : '', " ").concat(isPast ? 'calendar-day-past' : '');

    // 如果是今天，设置为选中状态
    if (isToday) {
      selectedDate = dateStr;
      updateEventsDisplay();
      updateAddEventButtonState(date);
    }

    // 日期数字
    var dayNumber = document.createElement('span');
    dayNumber.className = isToday ? 'font-weight-bold' : '';
    dayNumber.textContent = date.getDate();

    // 星期几（简短显示）
    var dayName = document.createElement('span');
    dayName.className = 'small mt-1';
    dayName.textContent = ['日', '一', '二', '三', '四', '五', '六'][date.getDay()];
    dayElement.appendChild(dayNumber);
    dayElement.appendChild(dayName);

    // 添加点击事件
    dayElement.addEventListener('click', function () {
      // 移除之前选中日期的样式
      document.querySelectorAll('.calendar-day-active').forEach(function (el) {
        el.classList.remove('calendar-day-active');
      });

      // 添加当前选中日期的样式
      dayElement.classList.add('calendar-day-active');

      // 更新选中日期并显示事件
      selectedDate = dateStr;
      updateEventsDisplay();
      updateAddEventButtonState(date);
    });

    // 如果有事件，添加指示点
    if (events[dateStr] && events[dateStr].length > 0) {
      var eventIndicator = document.createElement('span');
      eventIndicator.className = "event-indicator ".concat(isToday ? 'bg-white' : isPast ? 'bg-secondary' : 'bg-primary');
      dayElement.appendChild(eventIndicator);
    }
    col.appendChild(dayElement);
    calendarDays.appendChild(col);
  });
};

// 更新月份和年份显示
var updateMonthYearDisplay = function updateMonthYearDisplay() {
  var monthYearElement = document.getElementById('current-month-year');
  var monthNames = ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'];

  // 检查所有显示的日期是否在同一个月
  var firstMonth = displayDates[0].getMonth();
  var lastMonth = displayDates[displayDates.length - 1].getMonth();
  var year = displayDates[0].getFullYear();
  var displayText = firstMonth === lastMonth ? "".concat(monthNames[firstMonth], " ").concat(year) : "".concat(monthNames[firstMonth], " - ").concat(monthNames[lastMonth], " ").concat(year);
  monthYearElement.textContent = displayText;
};

// 更新事件显示
var updateEventsDisplay = function updateEventsDisplay() {
  var eventsContainer = document.getElementById('events-container');

  // 清空容器
  eventsContainer.innerHTML = '';

  // 如果没有事件
  if (!events[selectedDate] || events[selectedDate].length === 0) {
    eventsContainer.innerHTML = "\n            <div class=\"text-center text-muted py-5\">\n                <i class=\"far fa-calendar text-3xl mb-2 opacity-30\"></i>\n                <p class=\"mb-0\">\u8BE5\u65E5\u671F\u6682\u65E0\u4E8B\u9879</p>\n            </div>\n        ";
    return;
  }

  // 按时间排序事件
  var sortedEvents = _toConsumableArray(events[selectedDate]).sort(function (a, b) {
    return a.time.localeCompare(b.time);
  });

  // 添加事件到容器
  sortedEvents.forEach(function (event, index) {
    var eventElement = document.createElement('div');
    eventElement.className = 'event-item bg-white p-3 rounded border mb-2 slide-in';
    eventElement.style.animationDelay = "".concat(index * 50, "ms");
    eventElement.innerHTML = "\n            <div class=\"d-flex justify-content-between align-items-start\">\n                <div>\n                    <h4 class=\"font-medium text-dark mb-1\">".concat(event.title, "</h4>\n                    ").concat(event.time ? "<p class=\"small text-primary mb-0\">".concat(event.time, "</p>") : '', "\n                    ").concat(event.description ? "<p class=\"small text-muted mt-1 mb-0\">".concat(event.description, "</p>") : '', "\n                </div>\n                <div class=\"delete-event text-muted\" data-index=\"").concat(index, "\">\n                    <i class=\"far fa-trash-can\"></i>\n                </div>\n            </div>\n        ");
    eventsContainer.appendChild(eventElement);

    // 添加删除事件监听
    eventElement.querySelector('.delete-event').addEventListener('click', function (e) {
      var index = parseInt(e.currentTarget.dataset.index);
      deleteEvent(index);
    });
  });
};

// 根据日期更新添加事件按钮状态
var updateAddEventButtonState = function updateAddEventButtonState(date) {
  var addButton = document.getElementById('add-event-btn');
  var isPast = date < today;
  if (isPast) {
    // 过去的日期 - 禁用按钮
    addButton.disabled = true;
    addButton.classList.add('disabled', 'opacity-50');
    addButton.classList.remove('btn-primary');
    addButton.classList.add('btn-secondary');
  } else {
    // 今天或未来的日期 - 启用按钮
    addButton.disabled = false;
    addButton.classList.remove('disabled', 'opacity-50', 'btn-secondary');
    addButton.classList.add('btn-primary');
  }
};

// 打开添加事件弹窗
var openEventModal = function openEventModal() {
  document.getElementById('modal-date').value = selectedDate;

  // 清空表单
  document.getElementById('event-title').value = '';
  document.getElementById('event-time').value = '';
  document.getElementById('event-description').value = '';

  // 使用Bootstrap模态框方法显示
  $('#event-modal').modal('show');

  // 聚焦到标题输入框
  setTimeout(function () {
    document.getElementById('event-title').focus();
  }, 300);
};

// 保存事件
var saveEvent = function saveEvent() {
  var date = document.getElementById('modal-date').value;
  var title = document.getElementById('event-title').value.trim();
  var time = document.getElementById('event-time').value;
  var description = document.getElementById('event-description').value.trim();

  // 验证标题
  if (!title) {
    alert('请输入事项标题');
    return;
  }

  // 创建事件对象
  var event = {
    title: title,
    time: time,
    description: description
  };

  // 保存到事件数据中
  if (!events[date]) {
    events[date] = [];
  }
  events[date].push(event);

  // 保存到本地存储
  localStorage.setItem('calendarEvents', JSON.stringify(events));

  // 关闭弹窗
  $('#event-modal').modal('hide');

  // 更新显示
  renderCalendarDays();
  updateEventsDisplay();
};

// 删除事件
var deleteEvent = function deleteEvent(index) {
  $.confirm('确定删除该事项吗？', function () {
    events[selectedDate].splice(index, 1);

    // 如果该日期没有事件了，删除该日期的键
    if (events[selectedDate].length === 0) {
      delete events[selectedDate];
    }

    // 保存到本地存储
    localStorage.setItem('calendarEvents', JSON.stringify(events));

    // 更新显示
    renderCalendarDays();
    updateEventsDisplay();
  });
};

// 设置事件监听器
var setupEventListeners = function setupEventListeners() {
  // 添加事项按钮
  document.getElementById('add-event-btn').addEventListener('click', openEventModal);

  // 保存事件按钮
  document.getElementById('save-event').addEventListener('click', saveEvent);

  // 按ESC键关闭弹窗
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && $('#event-modal').hasClass('show')) {
      $('#event-modal').modal('hide');
    }
  });

  // 按Enter键保存事件（当弹窗打开时）
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && $('#event-modal').hasClass('show')) {
      saveEvent();
    }
  });
};

// 格式化日期为YYYY-MM-DD
var formatDate = function formatDate(date) {
  var year = date.getFullYear();
  var month = String(date.getMonth() + 1).padStart(2, '0');
  var day = String(date.getDate()).padStart(2, '0');
  return "".concat(year, "-").concat(month, "-").concat(day);
};

// 封装图表初始化逻辑
var initUserChart = function initUserChart(registerData) {
  var sparklineData = registerData.counts;
  var spark3 = {
    chart: {
      id: 'sparkline3',
      group: 'sparklines',
      type: 'area',
      height: 67,
      sparkline: {
        enabled: true
      }
    },
    stroke: {
      curve: 'smooth'
    },
    fill: {
      opacity: 1
    },
    series: [{
      name: '新注册用户',
      data: sparklineData
    }],
    labels: registerData.dates,
    xaxis: {
      type: 'text'
    },
    yaxis: {
      min: 0
    },
    colors: ['#008FFB']
  };

  // 渲染图表
  new ApexCharts(document.querySelector("#spark3"), spark3).render();
};
var initGroupChart = function initGroupChart(grouprData) {
  var options = {
    series: grouprData.series,
    chart: {
      type: 'donut'
    },
    labels: grouprData.labels,
    // 新增全局图例配置
    legend: {
      position: 'bottom',
      // 可选值：'top'、'bottom'
      horizontalAlign: 'center' // 水平对齐方式（可选）
    }
  };
  var chart = new ApexCharts(document.querySelector("#js-chartjs-pie"), options);
  chart.render();
};
var renderLastPostsAndThread = function renderLastPostsAndThread(threadData) {
  // 转换日期格式：将完整日期转为只显示日（10月15日 -> 15），同时处理跨年日期
  var formattedDates = threadData['days'].map(function (dateStr) {
    var _dateStr$split = dateStr.split('-'),
      _dateStr$split2 = _slicedToArray(_dateStr$split, 3),
      year = _dateStr$split2[0],
      month = _dateStr$split2[1],
      day = _dateStr$split2[2];
    // 添加跨年标识（如果包含去年）
    if (new Date().getFullYear() - year > 0) {
      return "".concat(month, "/").concat(day);
    }
    return "".concat(parseInt(day, 10), "\u65E5");
  });
  var options = {
    series: [{
      name: '发帖数',
      data: threadData['new_threads']
    }, {
      name: '回帖数',
      data: threadData['new_replies']
    }],
    chart: {
      type: 'bar',
      height: 293,
      stacked: true,
      // 移除顶部工具栏
      toolbar: {
        show: false
      },
      // 移除菜单按钮
      zoom: {
        enabled: false
      },
      selection: {
        enabled: false
      }
    },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 4,
        // 统一的圆角
        columnWidth: '65%',
        // 更紧凑的宽度
        dataLabels: {
          position: 'center' // 数值显示在顶部
        }
      }
    },
    dataLabels: {
      enabled: true,
      formatter: function formatter(val) {
        return val > 0 ? val : ''; // 0值不显示
      },
      style: {
        fontSize: '10px',
        colors: ['#444']
      }
    },
    xaxis: {
      type: 'category',
      categories: formattedDates,
      // 使用转换后的日期
      axisBorder: {
        show: false
      },
      // 移除轴线
      axisTicks: {
        show: false
      },
      // 移除刻度线
      labels: {
        style: {
          fontSize: '11px',
          fontWeight: 600
        }
      }
    },
    yaxis: {
      show: false // 隐藏Y轴
    },
    legend: {
      position: 'bottom',
      fontSize: '12px',
      markers: {
        width: 10,
        height: 10,
        radius: 3
      },
      itemMargin: {
        horizontal: 12
      }
    },
    grid: {
      show: false,
      // 移除网格线
      padding: {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
      }
    },
    tooltip: {
      x: {
        // 提示框显示完整日期
        formatter: function formatter(_, opts) {
          return threadData['days'][opts.dataPointIndex];
        }
      },
      y: {
        title: {
          formatter: function formatter(seriesName) {
            return seriesName;
          }
        }
      }
    }
  };
  var chart = new ApexCharts(document.querySelector("#threadDataChart"), options);
  chart.render();
};

/* JS部分 - 动态渲染表格 */
var renderGroupTable = function renderGroupTable(groupTableData) {
  var tbody = document.getElementById('group-table-body');
  var html = '';
  groupTableData.forEach(function (group) {
    var userAvatars = '';

    // 生成用户头像HTML
    group.users.forEach(function (user) {
      userAvatars += "\n                <a href=\"".concat(user.profile_url, "\" \n                   data-toggle=\"tooltip\" \n                   data-placement=\"top\" \n                   title=\"").concat(user.username, "\">\n                    <img src=\"").concat(user.avatar, "\" class=\"avatar-2\">\n                </a>\n            ");
    });

    // 生成行HTML
    html += "\n        <tr>\n            <td data-label=\"ID\">".concat(group.gid, "</td>\n            <td data-label=\"\u7528\u6237\u7EC4\u540D\u79F0\"><a href=\"").concat(group.list_url, "\">").concat(group.name, "</a></td>\n            <td data-label=\"\u6210\u5458\"><div>").concat(userAvatars, "</div></td>\n            <td data-label=\"\u6210\u5458\u6570\">\n                <span class=\"badge ").concat(group.badge_color, "\">").concat(group.count, "</span>\n            </td>\n        </tr>\n        ");
  });
  tbody.innerHTML = html;

  // 初始化tooltip（如使用Bootstrap）
  if ($) {
    $('[data-toggle="tooltip"]').tooltip();
  }
};
