$(function () {
        const $scrollingAlert = $('#scrollingAlert');
        const $scrollingText = $('#scrollingText');
        const $scrollingTextContainer = $('#scrollingTextContainer');
        const $navbar = $('#header');
		const $navbarInner = $('.navbar');
        const height = $navbar.outerHeight();

        // 检查文字长度是否超过容器宽度
        $scrollingText.css('animation-play-state', $scrollingText.outerWidth() > $scrollingTextContainer.outerWidth() ? 'running' : 'paused');

        // 鼠标移入时暂停动画
        $scrollingAlert.on('mouseenter', () => $scrollingText.css('animation-play-state', 'paused'));

        // 鼠标移出时恢复动画
        $scrollingAlert.on('mouseleave', () => {
            if ($scrollingText.outerWidth() > $scrollingTextContainer.outerWidth()) {
                $scrollingText.css('animation-play-state', 'running');
            }
        });

        $('.index_main_left, .aside').theiaStickySidebar({ additionalMarginTop: 77 });

        const _slider_left = new mSlider({ dom: ".slider-left", direction: "left", distance: "75%" });
        const _slider_right = new mSlider({ dom: ".slider-right", direction: "right", distance: "100%" });

        $('.header_nav_2_toggler').on('click', () => {
            _slider_left.open();
            $('.slider-left').show();
        });

        $('.header_nav_2_mobile_menu_bar').on('click', () => {
            _slider_right.open();
            $('.slider-right').show();
        });

        $('.close-slider-right-icon').on('click', () => _slider_right.close());
        $(window).on('scroll', () => {
            const scrollTop = $(this).scrollTop();
            $navbar.toggleClass('fixed-top', scrollTop > 0);
            $navbarInner.toggleClass('high-blur-bg', scrollTop > 0);
            $('body').css('padding-top', scrollTop > 0 ? height + 'px' : '0px');
        });

        $scrollingText.on('click', () => $.alert($scrollingText.html()));
        $('[data-toggle="tooltip"]').tooltip();
        $('[data-toggle="popover"]').popover();

        // 获取所有复选框和功能面板
    const checkboxes = document.querySelectorAll('.thread_checkbox');
    const modFuncPanel = document.querySelector('.thread_mod_func');
    
    // 如果没有找到元素则退出
    if (!modFuncPanel || checkboxes.length === 0) return;
    
    // 为每个复选框添加事件监听器
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            // 检查是否有任何复选框被选中
            const anyChecked = Array.from(checkboxes).some(cb => cb.checked);
            
            // 根据是否有选中的复选框来切换面板显示
            if (anyChecked) {
                modFuncPanel.classList.add('show');
            } else {
                modFuncPanel.classList.remove('show');
            }
        });
    });
    
    // 添加关闭按钮事件
    const closeBtn = modFuncPanel.querySelector('.close_mod');
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            // 取消所有选中的复选框
            checkboxes.forEach(cb => cb.checked = false);
            // 隐藏面板
            modFuncPanel.classList.remove('show');
        });
    }
    });
	// 滚动到指定ID的元素
	function scrollToId(id) {
		console.log(id);
		
		var target = $(id); // 获取目标元素
		if (target.length) {
			$('html, body').animate({
				scrollTop: target.offset().top // 滚动到目标元素的位置
			}, 1000); // 动画时间，单位为毫秒
		} else {
			console.error('未找到ID为 ' + id + ' 的元素');
		}
	}


    function cancelReply() {
        const jthis = $('.mod_post_reply');
        const tid = jthis.data('tid');
        const jli = jthis.closest('.post');
        jli.removeClass('quote');
        $('#quick_reply_form').find('input[name="quotepid"]').val(0);
        $('#advanced_reply').attr('href', xn.url('post-create-' + tid));
        $('.qusername').text('');
        $('.replying').hide('fast');
    }