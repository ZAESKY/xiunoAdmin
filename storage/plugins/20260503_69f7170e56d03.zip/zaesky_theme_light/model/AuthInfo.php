<?php
// 授权信息类
class AuthInfo{
    private static $authcode;
    const VERSION = '111';
    const EDITION = '3.4.1';
    const PUBLIC_KEY = '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxdBKJFbn0qmBixUdzXp6
SkBKlVMbJV+94C26AA5LalFZS7DFhYLhvLe/zCJ7ARY6RYxNh0ijTEmGV29vEUSO
G8iBM2QHPIdTmZ+l0B55gUWVFpMmutvEfYGe386kHpcP6Tse+8nIZyMeDTFDrp3c
Q1MqbjM7MPtuuQl9aa03iVKt88fERDEIQ+tzXk1psRloCd66m4hFHgNpk/E9jjwr
nUEKOzSE8bv7t1gmp4lJBlXgWfde6QY6jJrP/5ssLE2GQEKF3R9DABhVsLgD2R45
A2B3nD2o+eYVQQ9B6mNn1gRIUG441JSGuRYEynmRy/UkB+i78ejW+VpNPjyg/bMp
6wIDAQAB
-----END PUBLIC KEY-----';
    
    public static function init($authcode) {
        self::$authcode = $authcode;
    }

    public static function getAuthcode() {
        if (!self::$authcode) {
            $setting = db_find_one('authCode', array());
            self::$authcode = $setting['code'] ?? '';
        }
        return self::$authcode;
    }
}
