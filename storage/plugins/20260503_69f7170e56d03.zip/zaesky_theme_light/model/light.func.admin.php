<?php
include _include(APP_PATH.'plugin/zaesky_theme_light/model/AuthInfo.php');
include _include(APP_PATH.'plugin/zaesky_theme_light/model/Authorizationori.php');
// 获取磁盘剩余空间
$freeSpace = function_exists('disk_free_space') ? disk_free_space(APP_PATH) : false;
// 获取磁盘总空间
$totalSpace = function_exists('disk_total_space') ? disk_total_space(APP_PATH) : false;

// 初始化已使用空间百分比变量
$usedPercentage = 0;

$today = strtotime(date('Y-m-d',time()))-1;
$new_threads_num = db_count('thread',array('create_date'=>array('>'=>$today)));
$new_posts_num = db_count('post',array('create_date'=>array('>'=>$today)));
$new_attach_num = db_count('attach',array('create_date'=>array('>'=>$today)));

// 检查是否成功获取到空间信息，并且总空间不为零
if ($freeSpace!== false && $totalSpace!== false && $totalSpace > 0) {
    // 将字节转换为 GB
    $diskTotalGB = $totalSpace / (1024 * 1024 * 1024);

    // 格式化输出，保留两位小数
    $diskTotalGBFormatted = number_format($diskTotalGB, 2);
    // 计算已使用空间
    $usedSpace = $totalSpace - $freeSpace;
    // 计算已使用空间百分比
    $usedPercentage = ($usedSpace / $totalSpace) * 100;
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if($action == 'checkUpdate') {
    if($method == 'GET') {
        $result = Authorization::updateMain('check');
        message(0, json_encode($result));
    }
}else if($action == 'update') {
    if($method == 'GET') {
        $result = Authorization::updateMain('update');
        message(0, $result['msg']);
    }
}else if($action == 'checkAuth') {
    if($method == 'GET') {
        $result = Authorization::checkIsAuth();
        message(0, json_encode($result));
    }
}

/**
 * 获取最近10天的每日注册用户统计
 * 
 * @return array 返回包含日期和注册人数的数组
 */
function get_daily_registration_stats() {
    // 获取最近10天的日期范围 (包含今天共10天)
    $end_time = time();
    $start_time = $end_time - 86400 * 9;  // 修正：获取10天完整周期（今+前9天）
    
    // 安全获取用户数据
    $users = db_find('user', [
        'create_date' => ['>=' => $start_time]
    ], ['create_date' => -1]);
    
    // 初始化日期统计数组（确保包含完整10天）
    $result = [];
    $current_date = $end_time;
    for ($i = 0; $i < 10; $i++) {
        $date_key = date('Y-m-d', $current_date);
        $result[$date_key] = 0;
        $current_date -= 86400; // 减去一天
    }
    
    // 处理查询结果（修复foreach错误）
    if ($users && is_array($users)) {
        foreach ($users as $user) {
            // 确保create_time存在
            if (!isset($user['create_date']) || !is_numeric($user['create_date'])) continue;
            
            $date = date('Y-m-d', $user['create_date']);
            if (isset($result[$date])) {
                $result[$date]++;
            }
        }
    }
    
    // 转换为所需的返回格式
    $final_result = [];
    krsort($result); // 确保日期顺序从新到旧
    
    foreach ($result as $date => $count) {
        $final_result[] = [
            'date' => $date,
            'count' => $count
        ];
    }
    
    return $final_result;
}

function get_daily_registration_stats_split() {
    // 获取原始数据
    $stats = get_daily_registration_stats(); // 使用之前定义的函数
    
    // 拆分成两个数组
    $result = [
        'dates' => array_column($stats, 'date'),
        'counts' => array_column($stats, 'count')
    ];
    
    return $result;
}

function get_user_group_data() {
    global $grouplist;
    $series = [];
    $labels = [];

    foreach ($grouplist as $_gid => $_group) {
        if ($_group['gid'] > 100) {
            // 获取分组用户数量
            $group_num = db_count('user', array('gid' => $_group['gid']));
            $series[] = (int)$group_num;
            // 转义处理单引号防止JS错误
            $labels[] = str_replace("'", "\\'", $_group['name']);
        }
    }

    return [
        'series' => $series,
        'labels' => $labels
    ];
}

function getGroupTableData() {
    global $grouplist, $conf;
    $output = [];
    
    foreach($grouplist as $_gid => $_group) {
        if($_group['gid'] <= 7 && $_group['gid'] > 0) {
            // 获取用户数量和用户数据
            $admin_group_num = db_count('user', ['gid' => $_group['gid']]);
            $admin_group_user = db_find('user', ['gid' => $_group['gid']], ['uid' => -1]);
            
            // 设置badge颜色 (兼容PHP 7.x)
            $badge_color = 'badge-secondary';
            switch ($_group['gid']) {
                case 1: $badge_color = 'badge-danger'; break;
                case 2: $badge_color = 'badge-warning'; break;
                case 4: $badge_color = 'badge-primary'; break;
                case 5: $badge_color = 'badge-success'; break;
                case 6: $badge_color = 'badge-info'; break;
                case 7: $badge_color = 'badge-dark'; break;
            }
            
            // 构建用户头像数据
            $users = [];
            $user_num = 1;
            foreach($admin_group_user as $user) {
                if($user_num++ > 6) break;
                $avatar = ($user['avatar'] != 0) 
                    ? '../' . $conf['upload_url'] . 'avatar/000/' . $user['uid'] . '.png?' . $user['avatar']
                    : '../view/img/avatar.png';
                
                $users[] = [
                    'uid' => $user['uid'],
                    'username' => $user['username'],
                    'avatar' => $avatar,
                    'profile_url' => url('user-update-'.$user['uid'])
                ];
            }
            
            // 添加到输出数组
            $output[] = [
                'gid' => $_group['gid'],
                'name' => $_group['name'],
                'list_url' => url('user-list-gid-'.$_group['gid'].'-1'),
                'users' => $users,
                'count' => $admin_group_num,
                'badge_color' => $badge_color
            ];
        }
    }
    
    return $output;
}

function getLast7DaysPosts() {
        // 计算日期范围（含时区处理）
        $end = time();
        $start = $end - 7 * 86400;
        
        // 初始化每天计数数组
        $days = [];
        for ($i = 0; $i < 7; $i++) {
            $days[date('Y-m-d', $end - ($i * 86400))] = [
                'new_threads' => 0,
                'new_replies' => 0
            ];
        }
        ksort($days); // 按日期升序排列
        
        // 获取7天内新主题（发帖）
        $new_threads = _getThreadCount($start, $end);
        // 获取7天内新回复（回帖）
        $new_replies = _getReplyCount($start, $end);
        
        // 合并数据
        return [
            'days'       => array_keys($days),
            'new_threads' => _formatArray($new_threads, $days),
            'new_replies' => _formatArray($new_replies, $days)
        ];
    }

     function _getThreadCount($start, $end) {
        // 查表：统计新主题
        return db_find('thread',array(
            'create_date' => array('>=' => $start, '<=' => $end)
        ), array(), 0, 9999);
    }

     function _getReplyCount($start, $end) {
        // 使用 Xiuno 官方插件兼容写法
            return db_find('post',array(
                'create_date' => array('>=' => $start, '<=' => $end),
                'isfirst' => 0 // 排除首帖
            ), array(), 0, 9999);

    }

     function _formatArray($items, $days) {
        // 初始化计数数组
        $counts = array_fill(0, 7, 0);
        
        if ($items) {
            foreach ($items as $item) {
                $day = date('Y-m-d', ($item['create_date'] + 8*3600));
                $idx = array_search($day, array_keys($days));
                if ($idx !== false) $counts[$idx]++;
            }
        }
        return $counts;
    }