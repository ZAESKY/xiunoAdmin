<?php

class AuthConfig {
    private static $config = [
        'AUTH_DOMAIN' => 'www.admindev.cc',
        'APP_API_KEY' => '2f2a1adf28694d724573915930912d19',
        'APPID' => '2',
        'METHOD' => 'post',
        'IS_HTTPS' => false,
        'TIME' => 68400,
        'QUEUE_TIME' => 60,
        'SESSION_NAME' => 'CheckAuthResult'
    ];

    public static function get($key) {
        return self::$config[$key] ?? null;
    }

    public static function getAll() {
        return self::$config;
    }

    public static function set($key, $value) {
        self::$config[$key] = $value;
    }
}

class RateLimiter {
    private static $prefix = 'rate_limit_';
    private static $cooldown_time = 120; // 冷却时间，单位为秒（3分钟）
    private static $max_requests = 10; // 最大请求次数

    // 检查是否可以发起请求
    public static function canRequest($key) {
        $cache_key = self::getCacheKey($key);
        $request_data = self::getCache($cache_key);

        // 如果缓存中没有数据，说明是第一次请求
        if (!$request_data) {
            self::recordRequest($key);
            return true;
        }

        // 解析缓存数据
        list($first_request_time, $request_count) = $request_data;

        // 如果距离第一次请求已经超过冷却时间，则重置请求次数
        if (time() - $first_request_time > self::$cooldown_time) {
            self::recordRequest($key);
            return true;
        }

        // 如果请求次数超过最大限制，则进入限制
        if ($request_count >= self::$max_requests) {
            return false;
        }

        // 增加请求次数
        self::incrementRequestCount($key);
        return true;
    }

    // 记录请求
    public static function recordRequest($key) {
        $cache_key = self::getCacheKey($key);
        $request_data = [time(), 1]; // 记录第一次请求时间和请求次数
        self::setCache($cache_key, $request_data, self::$cooldown_time);
    }

    // 增加请求次数
    private static function incrementRequestCount($key) {
        $cache_key = self::getCacheKey($key);
        $request_data = self::getCache($cache_key);
        if ($request_data) {
            $request_data[1]++; // 增加请求次数
            self::setCache($cache_key, $request_data, self::$cooldown_time);
        }
    }

    // 获取剩余时间
    public static function getRemainingTime($key) {
        $cache_key = self::getCacheKey($key);
        $request_data = self::getCache($cache_key);
        if ($request_data) {
            $first_request_time = $request_data[0];
            return self::$cooldown_time - (time() - $first_request_time);
        }
        return 0;
    }

    // 获取缓存键名
    private static function getCacheKey($key) {
        return self::$prefix . $key;
    }

    // 获取缓存
    private static function getCache($key) {
        return cache_get($key);
    }

    // 设置缓存
    private static function setCache($key, $value, $ttl) {
        cache_set($key, $value, $ttl);
    }

    // 删除缓存
    private static function deleteCache($key) {
        cache_delete($key);
    }
}

class Authorization {
    // 盗版提示
    private static function message($msg = '') {
        message(-1, '<div class="text-center"><h2 class="text-danger mb-4"><i class="icon-times-circle"></i> 错误提示</h2><div class="alert alert-danger mb-4"><h5><i class="icon-exclamation-circle"></i> 错误信息</h5><p>'.$msg.'</p></div></div>');
        exit;
    }

    // 检测授权
    public static function main() {
        $SF_CheckAuthResult = self::getSession();
        if (!empty($SF_CheckAuthResult) && is_array($SF_CheckAuthResult)) {
            self::handleAuthResult($SF_CheckAuthResult);
            return $SF_CheckAuthResult['msg'];
        } else {
            self::handleNoAuthResult();
            $result = self::checkInfo();
            return $result['msg'];
        }
    }

    private static function handleAuthResult($result) {
        if (self::verifySign(json_encode($result['data']['data']), $result['data']['sign'])) {
            if (($result['data']['data']['time'] + AuthConfig::get('TIME')) > time()) {
                if ($result['data']['data']['code'] != 0) {
                    self::deleteSession();
                    self::message($result['msg']);
                }
            } else {
                self::deleteSession();
            }
        } else {
            self::deleteSession();
            self::message('签名验证失败，请刷新后重试~');
        }
    }

    private static function handleNoAuthResult() {
        $result = self::checkInfo();
        if (!$result) {
            self::message('链接服务器失败');
        } else {
            switch ($result['data']['data']['code']) {
                case 0:
                    self::setSession($result);
                    break;
                case 1:
                    // 自定义代码可在此填入
                    break;
                default:
                    self::message($result['msg']);
            }
        }
    }

     // 检查是否为本地IP
     private static function isLocalIp($ip) {
        return in_array($ip, ['127.0.0.1', '::1']);
        // return in_array($ip, []);
    }

    // 主入口方法
    public static function updateMain($SF_Action = 'check') {
        $user_ip = $_SERVER['REMOTE_ADDR']; // 使用用户IP作为限制的key

        // // 检查是否为本地IP
        // if (self::isLocalIp($user_ip)) {
        //     return ['code' => -1, 'msg' => '本地IP访问被禁止。'];
        // }

        if (!RateLimiter::canRequest($user_ip)) {
            $remaining_time = RateLimiter::getRemainingTime($user_ip);
            return ['code' => -1, 'msg' => '请求过于频繁，请在 ' . $remaining_time . ' 秒后再试。'];
        }

        $result = self::checkInfo('update');
        if (!$result) {
            return ['code' => -1, 'msg' => '啊哦，更新服务器开小差了，请刷新此页面。'];
        }
        switch ($SF_Action) {
            case 'check':
                return $result;
            case 'update':
                return self::performUpdate($result);
            default:
                return ['code' => -1, 'msg' => '请求类型错误！'];
        }
    }


    public static function checkIsAuth() {
        if (!($result = self::checkInfo('auth'))) {
            return [
                'code' => -1, 
                'msg' => '啊哦，更新服务器开小差了，请刷新此页面。'
            ];
        }
        return $result;
    }

    private static function performUpdate($result) {
        // 检查是否有可用更新
        if (empty($result['data']['data']['data'])) {
            return ['code' => 1, 'msg' => '已更新至最新版本'];
        }

        $updateData = $result['data']['data']['data'];
        $downloadUrl = $updateData['url'];
        $zipFile = 'SF.zip';
        $zipExtractPath = APP_PATH . 'plugin';

        // 设置下载UA
        ini_set('user_agent', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727;)');

        // 下载并解压更新包
        foreach ($updateData['download'] as $res) {
            if (!copy($downloadUrl . $res, $zipFile)) {
                return ['code' => -1, 'msg' => '无法下载更新包文件！'];
            }

            if (self::zipExtract($zipFile, $zipExtractPath)) {
                self::handleDatabaseUpdate();
                @unlink($zipFile);
                return ['code' => 0, 'msg' => '更新完成！即将为您刷新页面！'];
            }

            @unlink($zipFile);
            return ['code' => -1, 'msg' => '解压更新包失败，请稍后重试'];
        }

        return ['code' => 1, 'msg' => '已更新至最新版本'];
    }

    private static function handleDatabaseUpdate() {
        if (function_exists("opcache_reset")) @opcache_reset();
        $sqlFile = APP_PATH.'plugin/zaesky_theme_light/update.sql';
        if (is_file($sqlFile)) {
            $sql = file_get_contents($sqlFile);
            $t = 0; $e = 0; $error = '';
            foreach (explode(';', $sql) as $query) {
                if (trim($query) == '') continue;
                if ($DB->exec($query) !== false) {
                    ++$t;
                } else {
                    ++$e;
                    $error .= $DB->error() . "\n";
                }
            }
            @unlink($sqlFile);
            return "数据库更新成功。SQL成功{$t}句/失败{$e}句";
        }
        return '';
    }

    private static function getParam() {
        global $conf, $dbconfig;
        if (!class_exists('AuthInfo')) {
            self::message('缺少授权信息类！');
        }
        return [
            'authcode' => AuthInfo::getAuthcode(),
            'version' => AuthInfo::VERSION,
            'beta' => 1,
        ];
    }

    private static function checkInfo($type = 'auth') {

        $user_ip = $_SERVER['REMOTE_ADDR'];

    // // 检查是否为本地IP
    // if (self::isLocalIp($user_ip)) {
    //     return ['code' => -1, 'msg' => '本地IP访问被禁止。'];
    // }

        $method = ($type === 'update') ? 'checkUpdate' : 'checkAuth';
        $data = [
            'auth_info' => getenv('HTTP_HOST'),
            'appid' => AuthConfig::get('APPID'),
            'api_key' => AuthConfig::get('APP_API_KEY'),
            'param' => base64_encode(json_encode(self::getParam()))
        ];
        $is_https = AuthConfig::get('IS_HTTPS') ? 'https://' : 'http://';
        $result = self::curl_request($is_https . AuthConfig::get('AUTH_DOMAIN') . '/api.php/Auth/' . $method, $data, AuthConfig::get('METHOD'), AuthConfig::get('IS_HTTPS'));
        $result = json_decode($result, true);
        
        if (is_array($result) && array_key_exists('queue', $result['data'])) {
            return self::handleQueueCheck($data);
        }
        return $result ?: false;
    }

    private static function handleQueueCheck($data) {
        $i = 0;
        while (true) {
            $result = self::curl_request(AuthConfig::get('AUTH_DOMAIN') . '/api.php/Auth/queueCheck', $data, AuthConfig::get('METHOD'), AuthConfig::get('IS_HTTPS'));
            $result = json_decode($result, true);
            if (is_array($result) && array_key_exists('queue', $result['data'])) {
                $i++;
                if ($i > AuthConfig::get('QUEUE_TIME')) {
                    return false;
                }
            } else {
                return $result;
            }
            sleep(1);
        }
    }

    private static function verifySign($data, $sign) {
        if (!class_exists('AuthInfo')) self::message('缺少授权信息类！');
        $publicKey = AuthInfo::PUBLIC_KEY;
        if (empty($publicKey)) self::message('缺少公钥，请重新到<a href="' . (AuthConfig::get('IS_HTTPS') ? 'https://' : 'http://') . AuthConfig::get('AUTH_DOMAIN') . '">授权站下载源码！');
        return (1 == openssl_verify($data, self::urlSafeBase64decode($sign), $publicKey, OPENSSL_ALGO_SHA256));
    }

    private static function urlSafeBase64decode($string) {
        $data = str_replace(['-', '_'], ['+', '/'], $string);
        $mod4 = strlen($data) % 4;
        if ($mod4) {
            $data .= substr('====', $mod4);
        }
        return base64_decode($data);
    }

    private static function zipExtract($filePath, $topath) {
        if (empty($topath) || empty($filePath)) {
            return false;
        }
        
        $zip = new \ZipArchive();
        if ($zip->open($filePath) === true) {
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $filename = $zip->getNameIndex($i);
                
                $isDir = substr($filename, -1) === '/';
                
                if ($isDir) {
                    if (!is_dir($topath . '/' . $filename)) {
                        @mkdir($topath . '/' . $filename, 0777, true);
                    }
                } else {
                    $dirname = dirname($topath . '/' . $filename);
                    if (!is_dir($dirname)) {
                        @mkdir($dirname, 0777, true);
                    }
                    
                    if (is_file($topath . '/' . $filename)) {
                        @unlink($topath . '/' . $filename);
                    }
                    
                    $s = $zip->getStream($filename);
                    if ($s) {
                        $data = stream_get_contents($s);
                        file_put_contents($topath . '/' . $filename, $data);
                        fclose($s);
                    }
                }
            }
            $zip->close();
            return true;
        }
        return false;
    }

    private static function getSession() {
        return $_SESSION[AuthConfig::get('SESSION_NAME')] ?? null;
    }

    private static function setSession($session = null) {
        $_SESSION[AuthConfig::get('SESSION_NAME')] = $session;
    }

    private static function deleteSession() {
        unset($_SESSION[AuthConfig::get('SESSION_NAME')]);
    }

    private static function curl_request($url, $data = [], $type = 'post', $https = false) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)');
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if ($https) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        }
        if (strtolower($type) == 'post') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        } elseif (!empty($data) && is_array($data)) {
            $url = $url . '?' . http_build_query($data);
        }
        curl_setopt($ch, CURLOPT_URL, $url);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result === false ? false : $result;
    }

    public static function validateAndSaveAuth($auth_code) {
        $user_ip = $_SERVER['REMOTE_ADDR'];

        // // 检查是否为本地IP
        // if (self::isLocalIp($user_ip)) {
        //     return ['code' => -1, 'message' => '本地IP访问被禁止。'];
        // }
        try {
            // 初始化授权信息
            AuthInfo::init($auth_code);
            
            // 检查授权
            $auth_result = Authorization::checkIsAuth();
            
            if($auth_result['code'] == 0) {
                // 使用事务确保数据一致性
                self::updateAuthCode($auth_code);
                return [
                    'code' => 0,
                    'message' => '授权成功！'
                ];
            } else {
                return [
                    'code' => -1,
                    'message' => '授权失败，请检查授权码是否正确！'
                ];
            }
        } catch (Exception $e) {
            return [
                'code' => -1,
                'message' => '授权处理过程出错：' . $e->getMessage()
            ];
        }
    }
    
    private static function updateAuthCode($auth_code) {
        // 使用预处理语句防止SQL注入
        db_delete('authCode', array());
        db_insert('authCode', array('code' => $auth_code));
    }
}
?>